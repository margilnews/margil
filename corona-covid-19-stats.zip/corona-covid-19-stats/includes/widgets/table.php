<?php 

$output = "<div id='app-$rand' class='cov-container'><table-view></table-view></div>";