<?php 

$output = "<div id='app-$rand' class='cov-container'><global-wide bgcolor='$bgcolor' textcolor='$textcolor' labelcases='$labelcases' labeldeaths='$labeldeaths' labelrecovered='$labelrecovered'></global-widget></div>";